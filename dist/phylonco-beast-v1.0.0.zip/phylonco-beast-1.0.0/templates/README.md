This is a placeholder for Beauti templates.
