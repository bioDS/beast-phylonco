This is a placeholder for Beauti templates for BEAST 2.7.
